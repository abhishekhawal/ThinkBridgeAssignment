﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Shopbridge_base.Domain.Models;

namespace Shopbridge_base.Domain.Services.Interfaces
{
    public interface IProductService
    {
        Product Add(Product item);
        IEnumerable<Product> GetAll();
        Product Find(int id);
        void Remove(int Id);
        Product Update(Product item);
    }
}
