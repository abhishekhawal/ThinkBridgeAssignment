﻿using Microsoft.Extensions.Logging;
using Shopbridge_base.Domain.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Shopbridge_base.Domain.Models;
namespace Shopbridge_base.Domain.Services
{
    public class ProductService : IProductService
    {
        private readonly ILogger<ProductService> logger;
        private static List<Product> demoProductList = new List<Product>();
        public Product Add(Product item)
        {
            item.Product_Id = new Random().Next(1001, 2000);
            demoProductList.Add(item);
            return item;
        }

        public Product Find(int Id)
        {
            var contactItem = demoProductList.Find(e => e.Product_Id == Id);
            return contactItem;
        }

        public IEnumerable<Product> GetAll()
        {
            demoProductList = demoProductList.ToList();
            return demoProductList;
        }

        public void Remove(int Id)
        {
            var itemToRemove = demoProductList.SingleOrDefault(r => r.Product_Id == Id);
            if (itemToRemove != null)
                demoProductList.Remove(itemToRemove);
        }

        public Product Update(Product item)
        {
            var itemToUpdate = demoProductList.SingleOrDefault(r => r.Product_Id == item.Product_Id);
            if (itemToUpdate != null)
            {
                itemToUpdate.Product_Name = item.Product_Name;
                itemToUpdate.Product_Desc = item.Product_Desc;
                itemToUpdate.Product_Price = item.Product_Price;
            }
            return itemToUpdate;
        }
    }
}
