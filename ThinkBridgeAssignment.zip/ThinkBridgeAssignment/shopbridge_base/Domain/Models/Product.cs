﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Domain.Models
{
    public class Product
    {
        [Key]
        public int Product_Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string Product_Name { get; set; }
        [Required]
        [MaxLength(200)]
        public string Product_Desc { get; set; }
        [Required]
        public double Product_Price { get; set; }

    }
}
